
import React from "react";
import NetworkBuilder from "./NetworkBuilder";

function App() {
  return <NetworkBuilder />;
}

export default App;
