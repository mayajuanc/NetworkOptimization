
import ReactFlow, { MiniMap, Controls, Background } from "react-flow-renderer";


const ReactFlowWrapper = ({ nodes, edges, onNodesChange, onEdgesChange, onConnect, onNodeClick, onEdgeClick, nodeTypes }) => (
  <ReactFlow
    nodes={nodes}
    edges={edges}
    onNodesChange={onNodesChange}
    onEdgesChange={onEdgesChange}
    onConnect={onConnect}
    onNodeClick={onNodeClick}
    onEdgeClick={onEdgeClick}
    fitView
    nodeTypes={nodeTypes}
    defaultEdgeOptions={{
      style: { cursor: "pointer" }, // Add pointer cursor globally
    }}
    
  >
    <MiniMap />
    <Controls />
    <Background />
  </ReactFlow>
);



export default ReactFlowWrapper;
