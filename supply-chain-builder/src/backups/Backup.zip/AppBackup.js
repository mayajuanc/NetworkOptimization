import * as XLSX from "xlsx";
import React, { useCallback, useState } from "react";
import ReactFlow, {
  addEdge,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  Handle,
} from "react-flow-renderer";

// Custom node components
const FactoryNode = ({ data }) => (
  <div
    style={{
      padding: 10,
      borderRadius: 5,
      backgroundColor: "#e0f7fa",
      border: "2px solid blue",
      width: "120px",
      height: "40px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <Handle type="target" position="left" style={{ background: "#555" }} />
    <strong></strong>
    <div style={{ textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
      {data.label}
    </div>
    <Handle type="source" position="right" style={{ background: "#555" }} />
  </div>
);

const WarehouseNode = ({ data }) => (
  <div
    style={{
      padding: 10,
      borderRadius: 5,
      backgroundColor: "#e8f5e9",
      border: "2px solid green",
      width: "120px",
      height: "40px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <Handle type="target" position="left" style={{ background: "#555" }} />
    <strong></strong>
    <div style={{ textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
      {data.label}
    </div>
    <Handle type="source" position="right" style={{ background: "#555" }} />
  </div>
);

const CustomerNode = ({ data }) => (
  <div
    style={{
      padding: 10,
      borderRadius: 5,
      backgroundColor: "#ffebee",
      border: "2px solid red",
      width: "120px",
      height: "40px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <Handle type="target" position="left" style={{ background: "#555" }} />
    <strong></strong>
    <div style={{ textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
      {data.label}
    </div>
    <Handle type="source" position="right" style={{ background: "#555" }} />
  </div>
);

const ProductNode = ({ data }) => (
  <div
    style={{
      borderRadius: "50%", // Make it round
      backgroundColor: "#fff59d",
      border: "2px solid orange",
      width: "80px",
      height: "80px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <Handle type="target" position="left" style={{ background: "#555" }} />
    <strong></strong>
    <div style={{ textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
      {data.label}
    </div>
    <Handle type="source" position="right" style={{ background: "#555" }} />
  </div>
);

const nodeTypes = {
  product: ProductNode,
  factory: FactoryNode,
  warehouse: WarehouseNode,
  customer: CustomerNode,
  
};

// Calculate positions for new nodes
const calculateNewNodePositions = (type, nodes, numberOfNodes) => {
  const nodesOfSameType = nodes.filter((node) => node.type === type);
  const positions = [];
  const horizontalSpacing = 300;

  if (nodesOfSameType.length > 0) {
    const lastSameTypeNode = nodesOfSameType[nodesOfSameType.length - 1];
    const basePosition = { x: lastSameTypeNode.position.x, y: lastSameTypeNode.position.y + 100 };
    for (let i = 0; i < numberOfNodes; i++) {
      positions.push({ x: basePosition.x, y: basePosition.y + i * 100 });
    }
  } else {
    const lastNode = nodes[nodes.length - 1];
    const basePosition = lastNode
      ? { x: lastNode.position.x + horizontalSpacing, y: 50 }
      : { x: 50, y: 50 };
    for (let i = 0; i < numberOfNodes; i++) {
      positions.push({ x: basePosition.x, y: basePosition.y + i * 100 });
    }
  }

  return positions;
};

const renderNodeProperties = (node, setSelectedNode) => {
  const properties = [];

  // Common properties for all node types
  properties.push(
    <div key="name">
      <label>Name: </label>
      <input
        type="text"
        value={node.data.label}
        onChange={(e) =>
          setSelectedNode({
            ...node,
            data: { ...node.data, label: e.target.value },
          })
        }
      />
    </div>
  );

  // Properties specific to node types
  if (node.type === "factory") {
    properties.push(
      <div key="description">
        <label>Description: </label>
        <input
          type="text"
          value={node.data.description}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, description: e.target.value },
            })
          }
        />
      </div>,
      <div key="latlon">
        <label>LatLon: </label>
        <input
          type="text"
          value={node.data.latlon}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, latlon: e.target.value },
            })
          }
        />
      </div>,
      <div key="productionCost">
        <label>Production Cost: </label>
        <input
          type="number"
          value={node.data.productionCost}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, productionCost: parseFloat(e.target.value) || 0 },
            })
          }
        />
      </div>,
      <div key="startingInventory">
        <label>Starting Inventory: </label>
        <input
          type="number"
          value={node.data.startingInventory}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, startingInventory: parseFloat(e.target.value) || 0 },
            })
          }
        />
      </div>,
      <div key="productionCapacity">
        <label>Production Capacity: </label>
        <input
          type="number"
          value={node.data.productionCapacity}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, productionCapacity: parseFloat(e.target.value) || 0 },
            })
          }
        />
      </div>
    );
  } else if (node.type === "warehouse" || node.type === "customer") {
    properties.push(
      <div key="description">
        <label>Description: </label>
        <input
          type="text"
          value={node.data.description}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, description: e.target.value },
            })
          }
        />
      </div>,
      <div key="latlon">
        <label>LatLon: </label>
        <input
          type="text"
          value={node.data.latlon}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, latlon: e.target.value },
            })
          }
        />
      </div>,
      <div key="handlingCost">
        <label>Handling Cost: </label>
        <input
          type="number"
          value={node.data.handlingCost}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, handlingCost: parseFloat(e.target.value) || 0 },
            })
          }
        />
      </div>,
      <div key="startingInventory">
        <label>Starting Inventory: </label>
        <input
          type="number"
          value={node.data.startingInventory}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, startingInventory: parseFloat(e.target.value) || 0 },
            })
          }
        />
      </div>,
      <div key="storageCapacity">
        <label>Storage Capacity: </label>
        <input
          type="number"
          value={node.data.storageCapacity}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, storageCapacity: parseFloat(e.target.value) || 0 },
            })
          }
        />
      </div>
    );
  } else if (node.type === "product") {
    properties.push(
      <div key="properties">
        <label>Properties: </label>
        <input
          type="text"
          value={node.data.properties}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, properties: e.target.value },
            })
          }
        />
      </div>,
      <div key="weight">
        <label>Weight: </label>
        <input
          type="number"
          value={node.data.weight}
          onChange={(e) =>
            setSelectedNode({
              ...node,
              data: { ...node.data, weight: parseFloat(e.target.value) || 0 },
            })
          }
        />
      </div>
    );
  }

  return properties;
};

const NetworkBuilder = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [nodeIdCounter, setNodeIdCounter] = useState(1);
  const [newNodeType, setNewNodeType] = useState("factory");
  const [numberOfNodes, setNumberOfNodes] = useState(1);
  const [selectedNode, setSelectedNode] = useState(null);

  const addNodes = () => {
    const positions = calculateNewNodePositions(newNodeType.toLowerCase(), nodes, numberOfNodes);

    const prefixMapping = {
      product: "P_",
      factory: "F_",
      warehouse: "W_",
      customer: "C_",
    };

    const newNodes = Array.from({ length: numberOfNodes }, (_, index) => ({
      id: `${nodeIdCounter + index}`,
      type: newNodeType.toLowerCase(),
      data: {
        label: `${prefixMapping[newNodeType.toLowerCase()]}${String(nodeIdCounter + index).padStart(3, "0")}`,
        description: "",
        latlon: "",
        productionCost: 0,
        handlingCost: 0,
        startingInventory: 0,
        productionCapacity: 0,
        storageCapacity: 0,
        properties: "",
        weight: 0,
      },
      position: positions[index],
    }));

    setNodes((nds) => [...nds, ...newNodes]);
    setNodeIdCounter((prev) => prev + numberOfNodes);
  };

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge({ ...params, animated: true }, eds)),
    []
  );

  const onNodeClick = (_, node) => {
    // Save current selected node's properties if any
    if (selectedNode) {
      setNodes((nds) =>
        nds.map((n) =>
          n.id === selectedNode.id
            ? { ...n, data: { ...n.data, ...selectedNode.data } } // Persist data changes
            : n
        )
      );
    }
  
    // Set the newly clicked node as selected
    setSelectedNode(node);
  };

  const handleSaveNodeData = (updatedData) => {
    setNodes((nds) =>
      nds.map((node) =>
        node.id === selectedNode.id ? { ...node, data: { ...node.data, ...updatedData } } : node
      )
    );
    setSelectedNode(null);
  };

  return (
    <div style={{ height: "100vh", display: "flex" }}>
      <div
        style={{
          padding: "10px",
          background: "#f4f4f4",
          display: "flex",
          gap: "10px",
          position: "absolute",
          top: 0,
          left: 0,
          zIndex: 10,
        }}
      >
        <select value={newNodeType} onChange={(e) => setNewNodeType(e.target.value)}>
          <option value="product">Product</option>
          <option value="factory">Factory</option>
          <option value="warehouse">Warehouse</option>
          <option value="customer">Customer</option>
        </select>
        <select value={numberOfNodes} onChange={(e) => setNumberOfNodes(parseInt(e.target.value))}>
          {Array.from({ length: 10 }, (_, i) => i + 1).map((num) => (
            <option key={num} value={num}>
              {num}
            </option>
          ))}
        </select>
        <button onClick={addNodes}>Add Nodes</button>
      </div>

      <div style={{ flexGrow: 1 }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onNodeClick={onNodeClick}
          fitView
          nodeTypes={nodeTypes}
        >
          <MiniMap />
          <Controls />
          <Background />
        </ReactFlow>
      </div>

      {selectedNode && (
        <div
          style={{
            width: "400px",
            background: "#f4f4f4",
            padding: "20px",
            boxShadow: "-2px 0 5px rgba(0, 0, 0, 0.1)",
          }}
        >
          <h3>{selectedNode.type.charAt(0).toUpperCase() + selectedNode.type.slice(1)} Properties</h3>
          {renderNodeProperties(selectedNode, setSelectedNode)}
          <button
            onClick={() => {
              handleSaveNodeData(selectedNode.data);
            }}
            style={{ marginTop: "10px" }}
          >
            OK
          </button>
          {/* Export Button */}
   <div
  style={{
    marginTop: "20px",
    textAlign: "center",
  }}
>
  <button
    onClick={() => {
      if (!selectedNode) return;

      // Filter nodes strictly by the selected node's type
      const filteredNodes = nodes.filter((node) => node.type === selectedNode.type);

      // Map properties for the selected node type
      const excelData = filteredNodes.map((node) => {
        // Create a base data object
        const baseData = {
          ID: node.id,
          Label: node.data.label,
          
        };

        // Add properties specific to the node type
        if (node.type === "factory") {
          baseData.ProductionCost = node.data.productionCost || "";
          baseData.StartingInventory = node.data.startingInventory || "";
          baseData.ProductionCapacity = node.data.productionCapacity || "";
        } else if (node.type === "warehouse") {
          baseData.HandlingCost = node.data.handlingCost || "";
          baseData.StartingInventory = node.data.startingInventory || "";
          baseData.StorageCapacity = node.data.storageCapacity || "";
        } else if (node.type === "customer") {
          baseData.HandlingCost = node.data.handlingCost || "";
          baseData.StartingInventory = node.data.startingInventory || "";
          baseData.StorageCapacity = node.data.storageCapacity || "";
        } else if (node.type === "product") {
          baseData.Properties = node.data.properties || "";
          baseData.Weight = node.data.weight || "";
        }

        return baseData;
      });

      // Convert data to Excel and download
      const worksheet = XLSX.utils.json_to_sheet(excelData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, `${selectedNode.type}_Nodes`);
      XLSX.writeFile(workbook, `${selectedNode.type}_Nodes_Data.xlsx`);
    }}
    style={{
      marginTop: "10px",
      padding: "10px",
      backgroundColor: "#007BFF",
      color: "white",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
    }}
  >
    Export {selectedNode.type.charAt(0).toUpperCase() + selectedNode.type.slice(1)} Data
  </button>
  {/* Import Button */}
  <input
    type="file"
    accept=".xlsx"
    onChange={(e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const binaryStr = event.target.result;
        const workbook = XLSX.read(binaryStr, { type: "binary" });

        // Assume the first sheet contains the data
        const sheetName = workbook.SheetNames[0];
        const sheetData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

        // Update nodes of the selected type
        setNodes((nds) =>
          nds.map((node) => {
            if (node.type === selectedNode.type) {
              const matchingData = sheetData.find((row) => row.ID === node.id);
              if (matchingData) {
                return {
                  ...node,
                  data: {
                    ...node.data,
                    label: matchingData.Label || node.data.label,
                    description: matchingData.Description || node.data.description,
                    latlon: matchingData.LatLon || node.data.latlon,
                    productionCost: matchingData.ProductionCost || node.data.productionCost,
                    handlingCost: matchingData.HandlingCost || node.data.handlingCost,
                    startingInventory: matchingData.StartingInventory || node.data.startingInventory,
                    productionCapacity: matchingData.ProductionCapacity || node.data.productionCapacity,
                    storageCapacity: matchingData.StorageCapacity || node.data.storageCapacity,
                    properties: matchingData.Properties || node.data.properties,
                    weight: matchingData.Weight || node.data.weight,
                  },
                };
              }
            }
            return node;
          })
        );
      };

      reader.readAsBinaryString(file);
    }}
    style={{
      marginTop: "10px",
      padding: "10px",
      display: "block",
      cursor: "pointer",
    }}
  />
</div>

          
        </div>
      )}
    </div>
  );
};

export default NetworkBuilder;

