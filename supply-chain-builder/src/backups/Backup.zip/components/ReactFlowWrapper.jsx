
import ReactFlow, { MiniMap, Controls, Background } from "react-flow-renderer";

const ReactFlowWrapper = ({ nodes, edges, onNodesChange, onEdgesChange, onConnect, onNodeClick, nodeTypes }) => (
  <ReactFlow
    nodes={nodes}
    edges={edges}
    onNodesChange={onNodesChange}
    onEdgesChange={onEdgesChange}
    onConnect={onConnect}
    onNodeClick={onNodeClick}
    fitView
    nodeTypes={nodeTypes}
  >
    <MiniMap />
    <Controls />
    <Background />
  </ReactFlow>
);

export default ReactFlowWrapper;
